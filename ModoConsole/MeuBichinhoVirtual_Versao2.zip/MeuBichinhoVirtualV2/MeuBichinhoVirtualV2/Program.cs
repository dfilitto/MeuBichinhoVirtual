﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Drawing;

namespace MeuBichinhoVirtualV2
{
    internal class Program
    {
        //Inicio da imagem
        static Bitmap ResizeImage(Bitmap image, int width, int height)
        {
            // Cria um novo Bitmap com a largura e altura desejadas
            Bitmap resizedImage = new Bitmap(width, height);

            // Desenha a imagem original no novo Bitmap usando as dimensões desejadas
            using (Graphics graphics = Graphics.FromImage(resizedImage))
            {
                graphics.DrawImage(image, 0, 0, width, height);
            }

            return resizedImage;
        }

        static string ConvertToAscii(Bitmap image)
        {
            // Caracteres ASCII usados para representar a imagem
            char[] asciiChars = { ' ', '.', ':', '-', '=', '+', '*', '#', '%', '@' };

            StringBuilder asciiArt = new StringBuilder();

            // Percorre os pixels da imagem e converte cada um em um caractere ASCII correspondente
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixelColor = image.GetPixel(x, y);
                    int grayScale = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                    int asciiIndex = grayScale * (asciiChars.Length - 1) / 255;
                    char asciiChar = asciiChars[asciiIndex];
                    asciiArt.Append(asciiChar);
                }
                asciiArt.Append(Environment.NewLine);
            }

            return asciiArt.ToString();
        }

        static void ExibirImagem(string imagePath, int width, int height)
        {
            // Caminho para a imagem que deseja exibir
            //string imagePath = @"C:\Users\Danilo Filitto\Downloads\Panda.jpg";

            // Carrega a imagem
            Bitmap image = new Bitmap(imagePath);

            // Redimensiona a imagem para a largura e altura desejadas
            int consoleWidth = width;
            int consoleHeight = height;
            Bitmap resizedImage = ResizeImage(image, consoleWidth, consoleHeight);

            // Converte a imagem em texto ASCII
            string asciiArt = ConvertToAscii(resizedImage);

            // Exibe o texto ASCII no console
            Console.WriteLine(asciiArt);
        }

        //fim da imagem
        static void GraverArquivoTexto(string nome, string nomeDono, float alimentado, float limpo, float feliz)
        {
            string fileContent = nome + Environment.NewLine;
            fileContent += nomeDono + Environment.NewLine;
            fileContent += alimentado + Environment.NewLine;
            fileContent += limpo + Environment.NewLine;
            fileContent += feliz + Environment.NewLine;
            //gravei no arquivo texto
            //coletar os dados do animal no arquivo texto
            string dir = Environment.CurrentDirectory + "\\";
            string file = dir + nome + nomeDono + ".txt";
            File.WriteAllText(file, fileContent);
        }
        static void LerArquivoTexto(string nome, string nomeDono, ref float alimentado, ref float limpo, ref float feliz)
        {
            //coletar os dados do animal no arquivo texto
            string dir = Environment.CurrentDirectory + "\\";
            string file = dir + nome + nomeDono + ".txt";
            if (File.Exists(file))
            {
                string[] dados = File.ReadAllLines(file);
                alimentado = float.Parse(dados[2]);
                limpo = float.Parse(dados[3]);
                feliz = float.Parse(dados[4]);
                if (alimentado <= 0 || limpo <= 0 || feliz <= 0)
                {
                    Console.WriteLine("Assistente virtual:");
                    Console.WriteLine("O seu bichinho esta muito fraco!!!!!");
                    Console.WriteLine("Vamos cuidar dele para você...");
                    Console.WriteLine("Pronto, ele esta saudável e feliz.");
                    alimentado = 100;
                    limpo = 100;
                    feliz = 100;
                    Console.ReadKey();
                }
            }
        }

        static void AtualizarStatus(ref float alimentado, ref float limpo, ref float feliz)
        {
            Random rand = new Random();
            int caracteristica = 0;
            caracteristica = rand.Next(3);
            //alterar o status do animal
            //0 - alimento; 1 - limpo; 2 - feliz
            switch (caracteristica)
            {
                case 0: alimentado -= rand.Next(40); break;
                case 1: limpo -= rand.Next(40); break;
                case 2: feliz -= rand.Next(40); break;
            }
        }

        static void ExibirStatus(float alimentado, float limpo, float feliz, int tipo)
        {
            if (tipo == 0)
            {
                Console.WriteLine("Status do meu bichinho");
                Console.WriteLine("Alimentado: {0}",alimentado);
                Console.WriteLine("Limpo: {0}", limpo);
                Console.WriteLine("Feliz: {0}", feliz);
            }

            if (tipo == 1)
            {
                if (alimentado > 30 && alimentado < 75)
                {
                    Console.WriteLine("Eu estou faminto!!!!!! Nada melhor do que uma comidinha...");
                }
                if (limpo > 30 && limpo < 75)
                {
                    Console.WriteLine("Nossa estou meio sujinho!!!!!! Nada melhor do que um banho...");
                }
                if (feliz > 30 && feliz < 75)
                {
                    Console.WriteLine("Fiquei em casa o dia todo!!!!!! Nada melhor do que brincar...");
                }
            }

            if (tipo == 2)
            {
                Console.WriteLine("Status do meu bichinho");
                Console.WriteLine("Alimentado: {0}", alimentado);
                Console.WriteLine("Limpo: {0}", limpo);
                Console.WriteLine("Feliz: {0}", feliz);
                Console.WriteLine("Nível de felicidade");
                if (alimentado > 30 && alimentado < 75)
                {
                    Console.WriteLine("Eu estou faminto!!!!!! Nada melhor do que uma comidinha...");
                }
                if (limpo > 30 && limpo < 75)
                {
                    Console.WriteLine("Nossa estou meio sujinho!!!!!! Nada melhor do que um banho...");
                }
                if (feliz > 30 && feliz < 75)
                {
                    Console.WriteLine("Fiquei em casa o dia todo!!!!!! Nada melhor do que brincar...");
                }
            }
        }
        static string Falar()
        {
            //falas do bichinho
            string[] frases = new string[3];
            frases[0] = "Nossa o dia foi muito lega, comi o sofa!!!!!!";
            frases[1] = "Que saudades passei o dia todo esperando você chegar!!!!";
            frases[2] = "Hoje assisti ao show da Xuxa.";

            Random rand = new Random();
            return frases[rand.Next(frases.Length)];
        }

        static void LerDados(ref string nome, ref string nomeDono)
        {
            Console.Write("Qual é o seu nome: ");
            nomeDono = Console.ReadLine();
            Console.Write("Qual é o nome do seu bichinho virtual:");
            nome = Console.ReadLine();
            Console.WriteLine("Olá {0}, eu sou o seu bichinho virtual", nomeDono);
        }
        static string Interagir(string nomeDono, ref float alimentado, ref float limpo, ref float feliz)
        {
            string entrada = "";
            Random rand = new Random();

            Console.WriteLine("O que vamos fazer hoje?", nomeDono);
            Console.Write("Brincar/Comer/Banho/Nada: ");
            entrada = Console.ReadLine().ToLower();
            switch (entrada)
            {
                case "brincar": feliz += rand.Next(30); break;
                case "comer": alimentado += rand.Next(30); break;
                case "banho": limpo += rand.Next(30); break;
            }
            if (feliz > 100) feliz = 100;
            if (alimentado > 100) alimentado = 100;
            if (limpo > 100) limpo = 100;

            return entrada;
        }
        static void Main(string[] args)
        {
            //dados do jogo
            string entrada = ""; //entrada de dados
            string foto = Environment.CurrentDirectory + "\\Panda.jpg";
            string nomeDono = ""; //nome do jogador
            //dados do bichinho
            string nome = "";
            float alimentado = 100;
            float limpo = 100;
            float feliz = 100;
        
            ExibirImagem(foto, 35, 25);
            Console.WriteLine("Meu Bichinho virtual");
            //entrada de dados
            LerDados(ref nome, ref nomeDono);
            //coletar os dados do animal no arquivo texto
            LerArquivoTexto(nome, nomeDono, ref alimentado, ref limpo, ref feliz);
            //o programa principal - brincar com o bichinho
            while (entrada.ToLower() != "nada" && alimentado > 0 && limpo > 0 && feliz >0)
            {
                //contato inicial
                Console.Clear();
                Console.WriteLine(Falar());
                Thread.Sleep(4000);
                //Atualizo as caracteristicas do animal
                AtualizarStatus(ref alimentado, ref limpo, ref feliz);
                Console.Clear();
                //exibo o status do bichinho
                ExibirStatus(alimentado, limpo, feliz, 1);             
                Thread.Sleep(4000);
                Console.Clear();
                //interação com o animal
                entrada = Interagir(nomeDono, ref alimentado, ref limpo, ref feliz); 
            }

            Console.Clear();
            if (alimentado <= 0 || limpo <= 0 || feliz <= 0)
            {
                Console.WriteLine("{0}, estou muito fraco....",nomeDono);
                Console.WriteLine("Você não cuidou de mim... Estou indo para o assistente virtual");
                Console.WriteLine("Nos vemos em breve!!!!!");
            }
            else
            {
                Console.WriteLine("{0}, não vejo a hora de brincar de novo com você.",nomeDono);
                Console.WriteLine("Volte logo!!!!!");
            }

            //armazenar os dados
            GraverArquivoTexto(nome, nomeDono, alimentado, limpo, feliz);
            Console.ReadKey();
        }
    }
}
