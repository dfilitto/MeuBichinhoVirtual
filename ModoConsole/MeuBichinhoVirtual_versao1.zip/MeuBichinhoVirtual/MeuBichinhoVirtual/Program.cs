﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Text;

namespace MeuBichinhoVirtual
{
    internal class Program
    {
        static Bitmap ResizeImage(Bitmap image, int width, int height)
        {
            // Cria um novo Bitmap com a largura e altura desejadas
            Bitmap resizedImage = new Bitmap(width, height);

            // Desenha a imagem original no novo Bitmap usando as dimensões desejadas
            using (Graphics graphics = Graphics.FromImage(resizedImage))
            {
                graphics.DrawImage(image, 0, 0, width, height);
            }

            return resizedImage;
        }

        static string ConvertToAscii(Bitmap image)
        {
            // Caracteres ASCII usados para representar a imagem
            char[] asciiChars = { ' ', '.', ':', '-', '=', '+', '*', '#', '%', '@' };

            StringBuilder asciiArt = new StringBuilder();

            // Percorre os pixels da imagem e converte cada um em um caractere ASCII correspondente
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixelColor = image.GetPixel(x, y);
                    int grayScale = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                    int asciiIndex = grayScale * (asciiChars.Length - 1) / 255;
                    char asciiChar = asciiChars[asciiIndex];
                    asciiArt.Append(asciiChar);
                }
                asciiArt.Append(Environment.NewLine);
            }

            return asciiArt.ToString();
        }

        static void ExibirImagem(string imagePath, int width, int height)
        {
            // Caminho para a imagem que deseja exibir
            //string imagePath = @"C:\Users\Danilo Filitto\Downloads\Panda.jpg";

            // Carrega a imagem
            Bitmap image = new Bitmap(imagePath);

            // Redimensiona a imagem para a largura e altura desejadas
            int consoleWidth = width;
            int consoleHeight = height;
            Bitmap resizedImage = ResizeImage(image, consoleWidth, consoleHeight);

            // Converte a imagem em texto ASCII
            string asciiArt = ConvertToAscii(resizedImage);

            // Exibe o texto ASCII no console
            Console.WriteLine(asciiArt);


        }
        static void Main(string[] args)
        {
            //o bichinho morre quando não form alimentado, limpo ou
            //não estiver feliz
            string nome = "";
            string entrada = "";
            string imagePath = @"C:\Users\danilo.filitto\Downloads\Panda.jpg";

            float alimentado = 0;
            float limpo = 0;
            float feliz = 0;

            Random rnd = new Random();

            int i = 0;
            //implementar F....
            while (entrada != "Sim")
            {
                Console.WriteLine("Meu bichinho virtual");
                Console.Write("Qual o nome do bichinho: ");
                nome = Console.ReadLine();
                Console.Write("O nome esta correto (Sim ou Não)?: ");
                entrada = Console.ReadLine();
                Console.Clear();
            }
            limpo = 100;
            alimentado = 100;
            feliz = 100;
            //o jogo acaba quando o bichinho morrer
            while (limpo > 0 && alimentado > 0 && feliz > 0) 
            {
                //muda o etado do bichinho
                alimentado = alimentado - rnd.Next(31);
                limpo = limpo - rnd.Next(31);
                feliz = feliz - rnd.Next(31);

                //esta vivo, mostrar o estado do bichinho
                Console.Clear();
                ExibirImagem(imagePath, 30, 20);
                Console.WriteLine("Estado do meu bichinho {0}", nome);
                entrada = "Você é muito legal, obrigado por tudo!!!!";
                if (limpo > 20 && limpo < 80)
                {
                    Console.WriteLine("Quero banho!!!!");
                    entrada = "";
                }
                if (alimentado > 20 && alimentado < 80)
                {
                    entrada = "";
                    Console.WriteLine("Quero comida!!!!");
                }
                if (feliz > 20 && feliz < 80)
                {
                    entrada = "";
                    Console.WriteLine("Quero cafuné!!!!");
                }
                Thread.Sleep(3000);
                Console.Clear();
                Console.WriteLine(entrada);
                Console.WriteLine("O que deseja fazer....");
                Console.Write("Dar (comida, banho ou brincar)?: ");
                entrada = Console.ReadLine();
                if (entrada ==  "comida") 
                    alimentado = alimentado + rnd.Next(20,61);
                if (entrada == "banho")
                    limpo = limpo + rnd.Next(20, 61);
                if (entrada == "brincar")
                    feliz = feliz + rnd.Next(20, 61);
                //corrigir valores
                if (alimentado > 100) alimentado = 100;
                if (limpo > 100) limpo = 100;
                if (feliz > 100) feliz = 100;
            }

            //Morreu!!!!!!
            Console.WriteLine("Que pena seu bichinho {0} morreu!!!",nome);
            Console.WriteLine("Limpo: {0}%", limpo);
            Console.WriteLine("Alimentado: {0}%", alimentado);
            Console.WriteLine("Feliz: {0}%", feliz);
            Console.ReadKey();
        }
    }
}
